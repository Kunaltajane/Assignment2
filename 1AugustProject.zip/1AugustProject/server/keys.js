module.exports={
    MONGOURI:"mongodb+srv://kunaltajane4301:admin@cluster0.obycjli.mongodb.net/?retryWrites=true&w=majority",
    JWT_SECRET:"effegwegrgw4"
}